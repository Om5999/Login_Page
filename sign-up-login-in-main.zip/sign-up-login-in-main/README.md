# sign-up-login-in
sign up and log in page using HTML, CSS, JS and PHP

I used my own logo, and there are some bugs, if you find it, update it.
bug: when you sign up, it will move to another file, I avoided by writing function that refreshes the webpage whenever you sign up, but it is still clear there.
